<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Auth::routes();
Route::get('/', function () {
    return view('welcome');
});
Route::get('/register', 'HomeController@index')->name('home');
Route::get('/home', 'HomeController@index')->name('home');

Route::middleware('can:manage-auditor')->group(function () {
    Route::get('auditors/create', 'Auditor\CreateController@create')->name('auditors/create');
    Route::post('auditors/create', 'Auditor\CreateController@create_post')->middleware('can:create,App\User');
    Route::get('auditors/manage', 'Auditor\CreateController@show')->name('auditors/manage');
	Route::get('auditors/edit/{id}', 'Auditor\CreateController@edit')->name('auditors/edit');
	Route::post('auditors/edit/{id}', 'Auditor\CreateController@update')->name('auditors/update');
	Route::delete('auditors/delete/{id}', 'Auditor\CreateController@destroy')->name('auditors/delete');
});

Route::middleware('can:manage-operator')->group(function () {
    Route::get('operators/create', 'Operator\CreateController@create')->name('operators/create');
    Route::post('operators/create', 'Operator\CreateController@create_post');
    Route::get('operators/manage', 'Operator\CreateController@show')->name('operators/manage');
	Route::get('operators/edit/{id}', 'Operator\CreateController@edit')->name('operators/edit');
	Route::post('operators/edit/{id}', 'Operator\CreateController@update')->name('operators/update');
	Route::delete('operators/delete/{id}', 'Operator\CreateController@destroy')->name('operators/delete');
});


    Route::get('eacodes/create', 'EaCode\CreateController@create')->name('eacodes/create');
	Route::post('eacodes/create', 'EaCode\CreateController@create_post');
	Route::get('eacodes/manage', 'EAcode\CreateController@show')->name('eacodes/manage');
	Route::get('eacodes/edit/{id}', 'EAcode\CreateController@edit')->name('eacodes/edit');
	Route::post('eacodes/edit/{id}', 'EAcode\CreateController@update')->name('eacodes/update');
	Route::delete('eacodes/delete/{id}', 'EAcode\CreateController@destroy')->name('eacodes/delete');
	
	Route::get('nacecodes/create', 'NaceCode\CreateController@create')->name('nacecodes/create');
	Route::post('nacecodes/create', 'NaceCode\CreateController@create_post');
	Route::get('nacecodes/manage', 'Nacecode\CreateController@show')->name('nacecodes/manage');
	Route::get('nacecodes/edit/{id}', 'Nacecode\CreateController@edit')->name('nacecodes/edit');
	Route::post('nacecodes/edit/{id}', 'Nacecode\CreateController@update')->name('nacecodes/update');
	Route::delete('nacecodes/delete/{id}', 'Nacecode\CreateController@destroy')->name('nacecodes/delete');
	
	
	Route::get('standards/create', 'Standard\CreateController@create')->name('standards/create');
	Route::post('standards/create', 'Standard\CreateController@create_post');
	Route::get('standards/manage', 'Standard\CreateController@show')->name('standards/manage');
	Route::get('standards/edit/{id}', 'Standard\CreateController@edit')->name('standards/edit');
	Route::post('standards/edit/{id}', 'Standard\CreateController@update')->name('standards/update');
	Route::delete('standards/delete/{id}', 'Standard\CreateController@destroy')->name('standards/delete');


Route::middleware('throttle', 'throttle:60,1')->group(function () {
    
});