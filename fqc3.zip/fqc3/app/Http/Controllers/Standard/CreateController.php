<?php

namespace App\Http\Controllers\Standard;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Standard;
use DB;

class CreateController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        // return view('standards');
    }

    public function create()
    {
        return view('standards/create');
    }

    public function create_post(Request $request)
    {
        $this->validate($request, [
            'name' => 'required|max:255|unique:standards',
        ]);
        $standard = new Standard;
        $standard->name = $request->name;

        $standard->save();
        return redirect('standards/create')->with('status', 'Standard Created!');
    }
	 public function show()
    {
		$standards = Standard::paginate(10);
       return view ('standards/displayStandards')->with('standards',$standards); 
		
    }
	
	
	 public function edit($id)
    { 
		 $standard = Standard::where('id', $id)->first();
        return view('standards/edit', compact('standard', 'id'));
    }
	
	  public function update(Request $request, $id)
    {
		
       $this->validate($request, [
            'name' => 'required|max:255|unique:standards',
        ]); 
		$standard=Standard::find($id);
		$standard->name= $request->name;
		
        $standard->save();
        return redirect('standards/manage')->with('status', 'Standard has been updated!!');
		
	
    }
	
	  public function destroy($id)
    {
         $standard= Standard::find($id);
         $standard->delete();  

        return redirect('standards/manage')->with('status', 'Standard has been deleted!!');
    }

	
	
}
