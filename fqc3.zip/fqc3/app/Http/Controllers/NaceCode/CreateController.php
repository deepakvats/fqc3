<?php

namespace App\Http\Controllers\NaceCode;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\NaceCode;
use App\EaCode;
use DB;

class CreateController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        // return view('auditors');
    }

    public function create()
    {
		$eacodes = EaCode::all();
        return view('nacecodes/create')->with('eacodes',$eacodes); 
    }

   public function create_post(Request $request)
    {
        $this->validate($request, [
            'code' => 'required|max:255|unique:ea_codes',
			'description' => 'required',
        ]);
		$eacode=$request->eacode;
		$eacode_id = EaCode::where('code', $eacode)->first()->id;
		  
        $nacecode = new NaceCode;
        $nacecode->code= $request->code;
		$nacecode->ea_code_id= $eacode_id;
		
		$nacecode->description = $request->description;

        $nacecode->save();
        return redirect('eacodes/create')->with('status', 'NaceCode Added!');
    }
	  public function show()
    {
		 $nacecodes = NaceCode::paginate(15);

       return view ('nacecodes/displayNaceCodes')->with('nacecodes',$nacecodes);
		
    }
	
	
	 public function edit($id)
    { 
		$nace = NaceCode::where('id', $id)->first();
		$ea_code_id=$nace->ea_code_id;
        $eacode = EaCode::where('id', $ea_code_id)->first(); 
		$all_ea= EaCode::all();
		
		return view('nacecodes/edit', compact('nace' , 'eacode' , 'id' , 'all_ea'));			 
        
    }
	
	  public function update(Request $request, $id)
    {
        $this->validate($request, [
            'code' => 'required|max:255',
        ]); 
        $nacecode=NaceCode::find($id);
		$nacecode->code= $request->code;
		$nacecode->ea_code_id= $request->ea_code;
		$nacecode->description= $request->description;
		
        $nacecode->save();

        return redirect('nacecodes/manage')->with('status', 'NaceCode has been updated!!'); 
		
	
    }
	
	  public function destroy($id)
    {
         $nacecode= NaceCode::find($id);
         $nacecode->delete();  

        return redirect('nacecodes/manage')->with('status', 'NaceCode has been deleted!!');
    }


	
}
