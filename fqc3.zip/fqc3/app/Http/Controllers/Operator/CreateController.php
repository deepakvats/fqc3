<?php

namespace App\Http\Controllers\Operator;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use DB;

class CreateController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        // return view('auditors');
    }

    public function create()
    {
        return view('operators/create');
    }

    public function create_post(Request $request)
    {
        $this->validate($request, [
            'name' => 'required|max:255',
            'email' => 'required|unique:users',
            'password' => 'required|min:5'
        ]);
        $auditor = new User;
        $auditor->name = $request->name;
        $auditor->password = bcrypt($request->password);
        $auditor->email = $request->email;
        $auditor->roles = "operator";

        $auditor->save();
        return redirect('operators/create')->with('status', 'Operator Created!');
    }
	 public function show()
    {
	   $operators = User::where('roles','operator')->paginate(10);
       return view ('operators/displayOperator')->with('operators',$operators); 
		
    }
	
	
	 public function edit($id)
    { 
		 $operator = User::where('id', $id)
                        ->first();

        return view('operators/edit', compact('operator', 'id'));
    }
	
	  public function update(Request $request, $id)
    {
        $this->validate($request, [
            'name' => 'required|max:255',
            'email' => 'required',
        ]); 
		$operator=User::find($id);
		$operator->name= $request->name;
		$operator->email= $request->email;
        $operator->save();
        return redirect('operators/manage')->with('status', 'Operator has been updated!!');
    }
	
	  public function destroy($id)
    {
         $operator= User::find($id);
         $operator->delete();  

        return redirect('operators/manage')->with('status', 'Operator has been deleted!!');
    }

	
	
}
