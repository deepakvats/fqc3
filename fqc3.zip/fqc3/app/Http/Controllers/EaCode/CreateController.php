<?php

namespace App\Http\Controllers\EaCode;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\EaCode;
use DB;

class CreateController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        // return view('auditors');
    }

    public function create()
    {
        return view('eacodes/create');
    }

   public function create_post(Request $request)
    {
        $this->validate($request, [
            'code' => 'required|max:255|unique:ea_codes',
			'description' => 'required',
        ]);
        $eacode = new EaCode;
        $eacode->code= $request->code;
		$eacode->description = $request->description;

        $eacode->save();
        return redirect('eacodes/create')->with('status', 'EACode Added!');
    }
	  public function show()
    {
		$eacodes = EaCode::paginate(10);
       return view ('eacodes/displayEaCodes')->with('eacodes',$eacodes); 
		
    }
	
	
	 public function edit($id)
    { 
		 $eacode = EaCode::where('id', $id)->first();
        return view('eacodes/edit', compact('eacode', 'id'));
    }
	
	  public function update(Request $request, $id)
    {
        $this->validate($request, [
            'code' => 'required|max:255',
			'description' => 'required',
        ]); 
        $eacode=EaCode::find($id);
		$eacode->code= $request->code;
		$eacode->description=$request->description;
        $eacode->save();
        return redirect('eacodes/manage')->with('status', 'EACode has been updated!!'); 
		
	
    }
	
	  public function destroy($id)
    {
         $eacode= EaCode::find($id);
         $eacode->delete();  

        return redirect('eacodes/manage')->with('status', 'EACode has been deleted!!');
    }


	
}
