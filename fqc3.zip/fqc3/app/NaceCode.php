<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NaceCode extends Model
{
  protected $table = 'nace_codes';
  public $timestamps = false;

}
