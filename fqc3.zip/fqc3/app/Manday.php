<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Manday extends Model
{
    //
}
