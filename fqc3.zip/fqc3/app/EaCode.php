<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EaCode extends Model
{
	protected $table = 'ea_codes';
    public $timestamps = false;

}
