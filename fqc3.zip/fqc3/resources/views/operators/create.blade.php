@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                    <div class="card-header">Create Operator</div>
                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif
                    @if (count($errors) > 0)
                        <div class="alert alert-danger">
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
                    <form method="POST" action="">
                        @csrf
                        @method('POST')
                        @input(['description' => 'Operator Name', 'type' => 'name', 'name' => 'name', 'value' => old('name')])
                        <br/><br/>
                        @input(['description' => 'Operator Email', 'type' => 'email', 'name' => 'email', 'value' => old('email')])
                        <br/><br/>
                        @input(['description' => 'Operator Password', 'type' => 'password', 'name' => 'password', 'value' => old('password')])
                        <br/><br/>
                        @input(['description' => '', 'type' => 'submit', 'name' => 'submit', 'value' => 'Submit'])
                    </form>
                    
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
