@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                    <div class="card-header">Create Auditor</div>
                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif
                    @if (count($errors) > 0)
                        <div class="alert alert-danger">
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
                    <form method="POST" action="">
                        @csrf
                        @method('POST')
                        @input(['description' => 'Auditor Name', 'type' => 'text', 'name' => 'name', 'value' => old('name')])
                        <br/><br/>
                        @input(['description' => 'Auditor Email', 'type' => 'email', 'name' => 'email', 'value' => old('email')])
                        <br/><br/>
                        @input(['description' => 'Auditor Password', 'type' => 'password', 'name' => 'password', 'value' => old('password')])
                       <br/><br/>
                        @input(['description' => 'Date of Birth', 'type' => 'date', 'name' => 'date_of_birth', 'value' => old('date_of_birth')])
                        <br/><br/>
                        @input(['description' => 'Address', 'type' => 'text', 'name' => 'address', 'value' => old('address')])
                        <br/><br/>
                        @input(['description' => 'Phone', 'type' => 'text', 'name' => 'phone', 'value' => old('phone')])
                        <br/><br/>
                        @input(['description' => 'Mobile', 'type' => 'text', 'name' => 'mobile', 'value' => old('mobile')])
                        <br/><br/>
                        @input(['description' => 'Profession', 'type' => 'text', 'name' => 'profession', 'value' => old('profession')])
                        <br/><br/>
                        @input(['description' => 'Fax', 'type' => 'text', 'name' => 'fax', 'value' => old('fax')])
                        <br/><br/>
                        @input(['description' => '', 'type' => 'submit', 'name' => 'submit', 'value' => 'Submit'])
                    </form>
                    
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
