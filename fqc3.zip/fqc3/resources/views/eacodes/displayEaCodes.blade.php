@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                    <div class="card-header">List Of EaCodes</div>
                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif
                    @if (count($errors) > 0)
                        <div class="alert alert-danger">
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
					
					
            @foreach ($eacodes as $ea)
            <div class="list">
			<div class="left"> {{ $ea->code }}</div>
			
			<div class="right"> 
			<a href="{{action('EAcode\CreateController@edit',$ea->id)}}">Edit</a>
			<form action="{{action('EAcode\CreateController@destroy', $ea->id)}}" method="post">
                    {{csrf_field()}}
                    <input name="_method" type="hidden" value="DELETE">
                    <button class="btn btn-danger" type="submit">Delete</button>
           </form>
		   </div>
		   </div>
            @endforeach
                    
                </div>
				{{ $eacodes->links() }}
            </div>
        </div>
    </div>
</div>
@endsection
