@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                    <div class="card-header">Create NACE Code</div>
                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif
                    @if (count($errors) > 0)
                        <div class="alert alert-danger">
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
                    <form method="POST" action="">
                        @csrf
                        @method('POST')
                        @input(['description' => 'Nace Code', 'type' => 'name', 'name' => 'code', 'value' => old('code')])
                        <br/><br/>
						<label>Select EA code:</label>
						<select name="eacode">
						 @foreach ($eacodes as $ea)
						<option value="{{$ea->code}}">{{$ea->code}}</option>
						@endforeach
						</select>
						<br/><br/>
                        <label>Description:</label> <textarea name="description"></textarea>
                        <br/><br/>
						
                        @input(['description' => '', 'type' => 'submit', 'name' => 'submit', 'value' => 'Submit'])
                    </form>
                    
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
