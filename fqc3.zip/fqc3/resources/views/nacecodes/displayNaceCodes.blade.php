@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                    <div class="card-header">
					<h5 class="heading">NACE Code</h5>
					<!---<h5 class="heading">EA Code</h5>--->
					<h5 class="heading last">Action</h5>
					</div>
                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif
                    @if (count($errors) > 0)
                        <div class="alert alert-danger">
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
					
			
            @foreach ($nacecodes as $na)
 
            <div class="list">
			 <span class="heading">{{ $na->code }} </span>
			<!---<span class="heading"> {{$na->ea_code_id}}</span>--->
			
			<div class="heading last"><a href="{{action('Nacecode\CreateController@edit',$na->id)}}">Edit</a>
			<form action="{{action('Nacecode\CreateController@destroy', $na->id)}}" method="post">
                    {{csrf_field()}}
                    <input name="_method" type="hidden" value="DELETE">
                    <button class="btn btn-danger" type="submit">Delete</button>
           </form></div>
		  
		   </div>
            @endforeach 
				
                </div>
				{{ $nacecodes->links() }}
            </div>
        </div>
    </div>
</div>
@endsection
