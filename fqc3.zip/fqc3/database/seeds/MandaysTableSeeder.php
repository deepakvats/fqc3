<?php

use Illuminate\Database\Seeder;

class MandaysTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
		 $standard1 = DB::table('standards')->where('name', 'ISO 9001:2015')->first()->id;
		 $standard2 = DB::table('standards')->where('name', 'ISO 14001:2015')->first()->id;
		 
		 $complexity_high= DB::table('complexities')->where('name', 'High')->first()->id;
		 $complexity_medium= DB::table('complexities')->where('name', 'Medium')->first()->id;
		 $complexity_low= DB::table('complexities')->where('name', 'Low')->first()->id;
		 $complexity_limited= DB::table('complexities')->where('name', 'Limited')->first()->id;
		 
        $data=[
		    ['minEmployees' => "1" , 'maxEmployees' => "5" , 'manday' => "2" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_high],
		    ['minEmployees' => "6" , 'maxEmployees' => "10" , 'manday' => "2.5" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "11" , 'maxEmployees' => "15" , 'manday' => "3" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "16" , 'maxEmployees' => "25" , 'manday' => "4" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "26" , 'maxEmployees' => "45" , 'manday' => "5" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "46" , 'maxEmployees' => "65" , 'manday' => "6.5" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "66" , 'maxEmployees' => "85" , 'manday' => "7.5" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "86" , 'maxEmployees' => "125" , 'manday' => "9" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "126" , 'maxEmployees' => "175" , 'manday' => "10" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "176" , 'maxEmployees' => "275" , 'manday' => "11.5" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "276" , 'maxEmployees' => "425" , 'manday' => "12.5" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "426" , 'maxEmployees' => "625" , 'manday' => "14" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "626" , 'maxEmployees' => "875" , 'manday' => "15" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "876" , 'maxEmployees' => "1175" , 'manday' => "16.5" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "1176" , 'maxEmployees' => "1550" , 'manday' => "17.5" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "1551" , 'maxEmployees' => "2025" , 'manday' => "19" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "2026" , 'maxEmployees' => "2675" , 'manday' => "20" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "2676" , 'maxEmployees' => "3450" , 'manday' => "21.5" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "3451" , 'maxEmployees' => "4350" , 'manday' => "22.5" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "4351" , 'maxEmployees' => "5450" , 'manday' => "24" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "5451" , 'maxEmployees' => "6800" , 'manday' => "25" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "6801" , 'maxEmployees' => "8500" , 'manday' => "26.5" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "8501" , 'maxEmployees' => "10700" , 'manday' => "27.5" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_high],
            
            ['minEmployees' => "1" , 'maxEmployees' => "5" , 'manday' => "1.5" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "6" , 'maxEmployees' => "10" , 'manday' => "2" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "11" , 'maxEmployees' => "15" , 'manday' => "2.5" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "16" , 'maxEmployees' => "25" , 'manday' => "3" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "26" , 'maxEmployees' => "45" , 'manday' => "4" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "46" , 'maxEmployees' => "65" , 'manday' => "5" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "66" , 'maxEmployees' => "85" , 'manday' => "6" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "86" , 'maxEmployees' => "125" , 'manday' => "7" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "126" , 'maxEmployees' => "175" , 'manday' => "8" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "176" , 'maxEmployees' => "275" , 'manday' => "9" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "276" , 'maxEmployees' => "425" , 'manday' => "10" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "426" , 'maxEmployees' => "625" , 'manday' => "11" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "626" , 'maxEmployees' => "875" , 'manday' => "12" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "876" , 'maxEmployees' => "1175" , 'manday' => "13" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "1176" , 'maxEmployees' => "1550" , 'manday' => "14" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "1551" , 'maxEmployees' => "2025" , 'manday' => "15" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "2026" , 'maxEmployees' => "2675" , 'manday' => "16" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "2676" , 'maxEmployees' => "3450" , 'manday' => "17" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "3451" , 'maxEmployees' => "4350" , 'manday' => "18" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "4351" , 'maxEmployees' => "5450" , 'manday' => "19" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "5451" , 'maxEmployees' => "6800" , 'manday' => "20" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "6801" , 'maxEmployees' => "8500" , 'manday' => "21" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "8501" , 'maxEmployees' => "10700" , 'manday' => "22" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_medium],
            
            
            
            
            ['minEmployees' => "1" , 'maxEmployees' => "5" , 'manday' => "1" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "6" , 'maxEmployees' => "10" , 'manday' => "1.5" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "11" , 'maxEmployees' => "15" , 'manday' => "2" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "16" , 'maxEmployees' => "25" , 'manday' => "2.5" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "26" , 'maxEmployees' => "45" , 'manday' => "3" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "46" , 'maxEmployees' => "65" , 'manday' => "4" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "66" , 'maxEmployees' => "85" , 'manday' => "4.5" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "86" , 'maxEmployees' => "125" , 'manday' => "5.5" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "126" , 'maxEmployees' => "175" , 'manday' => "6" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "176" , 'maxEmployees' => "275" , 'manday' => "7" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "276" , 'maxEmployees' => "425" , 'manday' => "7.5" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "426" , 'maxEmployees' => "625" , 'manday' => "8.5" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "626" , 'maxEmployees' => "875" , 'manday' => "9" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "876" , 'maxEmployees' => "1175" , 'manday' => "10" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "1176" , 'maxEmployees' => "1550" , 'manday' => "10.5" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "1551" , 'maxEmployees' => "2025" , 'manday' => "11.5" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "2026" , 'maxEmployees' => "2675" , 'manday' => "12" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "2676" , 'maxEmployees' => "3450" , 'manday' => "13" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "3451" , 'maxEmployees' => "4350" , 'manday' => "13.5" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "4351" , 'maxEmployees' => "5450" , 'manday' => "14.5" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "5451" , 'maxEmployees' => "6800" , 'manday' => "15" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "6801" , 'maxEmployees' => "8500" , 'manday' => "16" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "8501" , 'maxEmployees' => "10700" , 'manday' => "16.5" , 'standard_id' => $standard1 , 'complexity_id' => $complexity_low],
            
            
            
            
            
            ['minEmployees' => "1" , 'maxEmployees' => "5" , 'manday' => "3" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_high],
		    ['minEmployees' => "6" , 'maxEmployees' => "10" , 'manday' => "3.5" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "11" , 'maxEmployees' => "15" , 'manday' => "4.5" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "16" , 'maxEmployees' => "25" , 'manday' => "5.5" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "26" , 'maxEmployees' => "45" , 'manday' => "7" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "46" , 'maxEmployees' => "65" , 'manday' => "8" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "66" , 'maxEmployees' => "85" , 'manday' => "9" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "86" , 'maxEmployees' => "125" , 'manday' => "11" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "126" , 'maxEmployees' => "175" , 'manday' => "12" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "176" , 'maxEmployees' => "275" , 'manday' => "13" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "276" , 'maxEmployees' => "425" , 'manday' => "15" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "426" , 'maxEmployees' => "625" , 'manday' => "16" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "626" , 'maxEmployees' => "875" , 'manday' => "17" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "876" , 'maxEmployees' => "1175" , 'manday' => "19" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "1176" , 'maxEmployees' => "1550" , 'manday' => "20" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "1551" , 'maxEmployees' => "2025" , 'manday' => "21" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "2026" , 'maxEmployees' => "2675" , 'manday' => "23" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "2676" , 'maxEmployees' => "3450" , 'manday' => "25" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "3451" , 'maxEmployees' => "4350" , 'manday' => "27" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "4351" , 'maxEmployees' => "5450" , 'manday' => "28" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "5451" , 'maxEmployees' => "6800" , 'manday' => "30" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "6801" , 'maxEmployees' => "8500" , 'manday' => "32" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_high],
            ['minEmployees' => "8501" , 'maxEmployees' => "10700" , 'manday' => "34" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_high],
            
            
            
            ['minEmployees' => "1" , 'maxEmployees' => "5" , 'manday' => "2.5" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "6" , 'maxEmployees' => "10" , 'manday' => "3" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "11" , 'maxEmployees' => "15" , 'manday' => "3.5" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "16" , 'maxEmployees' => "25" , 'manday' => "4.5" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "26" , 'maxEmployees' => "45" , 'manday' => "5.5" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "46" , 'maxEmployees' => "65" , 'manday' => "6" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "66" , 'maxEmployees' => "85" , 'manday' => "7" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "86" , 'maxEmployees' => "125" , 'manday' => "8" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "126" , 'maxEmployees' => "175" , 'manday' => "9" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "176" , 'maxEmployees' => "275" , 'manday' => "10" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "276" , 'maxEmployees' => "425" , 'manday' => "11" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "426" , 'maxEmployees' => "625" , 'manday' => "12" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "626" , 'maxEmployees' => "875" , 'manday' => "13" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "876" , 'maxEmployees' => "1175" , 'manday' => "15" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "1176" , 'maxEmployees' => "1550" , 'manday' => "16" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "1551" , 'maxEmployees' => "2025" , 'manday' => "17" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "2026" , 'maxEmployees' => "2675" , 'manday' => "18" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "2676" , 'maxEmployees' => "3450" , 'manday' => "19" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "3451" , 'maxEmployees' => "4350" , 'manday' => "20" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "4351" , 'maxEmployees' => "5450" , 'manday' => "21" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "5451" , 'maxEmployees' => "6800" , 'manday' => "23" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "6801" , 'maxEmployees' => "8500" , 'manday' => "25" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_medium],
            ['minEmployees' => "8501" , 'maxEmployees' => "10700" , 'manday' => "27" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_medium],
            
            
            
            
            ['minEmployees' => "1" , 'maxEmployees' => "5" , 'manday' => "2.5" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "6" , 'maxEmployees' => "10" , 'manday' => "3" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "11" , 'maxEmployees' => "15" , 'manday' => "3" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "16" , 'maxEmployees' => "25" , 'manday' => "3.5" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "26" , 'maxEmployees' => "45" , 'manday' => "4" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "46" , 'maxEmployees' => "65" , 'manday' => "4.5" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "66" , 'maxEmployees' => "85" , 'manday' => "5" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "86" , 'maxEmployees' => "125" , 'manday' => "5.5" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "126" , 'maxEmployees' => "175" , 'manday' => "6" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "176" , 'maxEmployees' => "275" , 'manday' => "7" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "276" , 'maxEmployees' => "425" , 'manday' => "8" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "426" , 'maxEmployees' => "625" , 'manday' => "9" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "626" , 'maxEmployees' => "875" , 'manday' => "10" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "876" , 'maxEmployees' => "1175" , 'manday' => "11" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "1176" , 'maxEmployees' => "1550" , 'manday' => "12" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "1551" , 'maxEmployees' => "2025" , 'manday' => "12" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "2026" , 'maxEmployees' => "2675" , 'manday' => "13" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "2676" , 'maxEmployees' => "3450" , 'manday' => "14" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "3451" , 'maxEmployees' => "4350" , 'manday' => "15" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "4351" , 'maxEmployees' => "5450" , 'manday' => "16" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "5451" , 'maxEmployees' => "6800" , 'manday' => "17" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "6801" , 'maxEmployees' => "8500" , 'manday' => "19" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_low],
            ['minEmployees' => "8501" , 'maxEmployees' => "10700" , 'manday' => "20" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_low],
            
            
            ['minEmployees' => "1" , 'maxEmployees' => "5" , 'manday' => "1.5" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_limited],
            ['minEmployees' => "6" , 'maxEmployees' => "10" , 'manday' => "2" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_limited],
            ['minEmployees' => "11" , 'maxEmployees' => "15" , 'manday' => "2.5" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_limited],
            ['minEmployees' => "16" , 'maxEmployees' => "25" , 'manday' => "3" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_limited],
            ['minEmployees' => "26" , 'maxEmployees' => "45" , 'manday' => "4" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_limited],
            ['minEmployees' => "46" , 'maxEmployees' => "65" , 'manday' => "5" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_limited],
            ['minEmployees' => "66" , 'maxEmployees' => "85" , 'manday' => "6" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_limited],
            ['minEmployees' => "86" , 'maxEmployees' => "125" , 'manday' => "7" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_limited],
            ['minEmployees' => "126" , 'maxEmployees' => "175" , 'manday' => "8" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_limited],
            ['minEmployees' => "176" , 'maxEmployees' => "275" , 'manday' => "9" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_limited],
            ['minEmployees' => "276" , 'maxEmployees' => "425" , 'manday' => "10" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_limited],
            ['minEmployees' => "426" , 'maxEmployees' => "625" , 'manday' => "11" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_limited],
            ['minEmployees' => "626" , 'maxEmployees' => "875" , 'manday' => "12" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_limited],
            ['minEmployees' => "876" , 'maxEmployees' => "1175" , 'manday' => "13" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_limited],
            ['minEmployees' => "1176" , 'maxEmployees' => "1550" , 'manday' => "14" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_limited],
            ['minEmployees' => "1551" , 'maxEmployees' => "2025" , 'manday' => "15" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_limited],
            ['minEmployees' => "2026" , 'maxEmployees' => "2675" , 'manday' => "16" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_limited],
            ['minEmployees' => "2676" , 'maxEmployees' => "3450" , 'manday' => "17" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_limited],
            ['minEmployees' => "3451" , 'maxEmployees' => "4350" , 'manday' => "18" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_limited],
            ['minEmployees' => "4351" , 'maxEmployees' => "5450" , 'manday' => "19" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_limited],
            ['minEmployees' => "5451" , 'maxEmployees' => "6800" , 'manday' => "20" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_limited],
            ['minEmployees' => "6801" , 'maxEmployees' => "8500" , 'manday' => "21" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_limited],
            ['minEmployees' => "8501" , 'maxEmployees' => "10700" , 'manday' => "22" , 'standard_id' => $standard2 , 'complexity_id' => $complexity_limited],
           
		];
		
        DB::table('mandays')->insert($data);
    }
}
