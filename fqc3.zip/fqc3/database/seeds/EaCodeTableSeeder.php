<?php

use Illuminate\Database\Seeder;


class EaCodeTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
		$codes=[
		['code' => "EA 01",'description' => "Tarım, balıkçılık/ Agriculture & Fishing & Forestry"],
		['code' => "EA 02",'description' => "Maden/ Mining and Quarrying"],
		['code' => "EA 03",'description' => "Gıda ürünleri, meşrubat ve tütün mamulleri/Food products, beverages and tobacco "],
		['code' => "EA 04",'description' => "Tekstil ve tekstil ürünleri/ Textiles and textile products"],
		['code' => "EA 05",'description' => "Deri ve deri ürünleri/ Leather & Leather products"],
		['code' => "EA 06",'description' => "Ağaç ve ağaç ürünleri/ Wood and wood products"],
		['code' => "EA 07",'description' => "Kağıt hamuru, kağıt ve kağıt ürünleri/ Pulp, paper, and paper products"],
		['code' => "EA 08",'description' => "Yayıncılık şirketleri/ Publishing Companies"],
		['code' => "EA 09",'description' => "Matbaacılık (basımevleri) şirketleri/ Printing companies"],
		['code' => "EA 10",'description' => "Petrol ve Petrol Ürünleri/ Manufacture of coke and refined petroleum products"],
		['code' => "EA 12",'description' => "Kimyasallar, kimyasal ürünler ve lifli ürünler/ Chemicals, chemical products and fibres"],
		['code' => "EA 13",'description' => "İlaç/ Pharmaceuticals"],
		['code' => "EA 14",'description' => "Kauçuk ve plastik ürünler/ Rubber and plastic products"],
		['code' => "EA 15",'description' => "Metal olmayan madeni ürünler/ Non-metallic mineral products"],
		['code' => "EA 16",'description' => "Beton, çimento, kireç, alçı, sıva vb./ Concrete, cement, lime, plaster etc."],
		['code' => "EA 17",'description' => "Temel metaller ve işlenmiş metal ürünleri/ Basic metals and fabricated metal products"],
		['code' => "EA 18",'description' => "Makine ve teçhizat/ Machinery and equipment"],
		['code' => "EA 19",'description' => "Elektrikli ve optik teçhizat/ Electrical equipment, Optical and precision equipments DL and Medical and surgical equipment"],
		['code' => "EA 20",'description' => "Gemi inşası/ Shipbuilding"],
		['code' => "EA 22",'description' => "Taşıt araçları, römork, motorsiklet/ Other transport equipment"],
		['code' => "EA 23",'description' => "Sınıflandırılmamış diğer sınai üretim/ Manufacturing not elsewhere classified"],
		['code' => "EA 24",'description' => "Geri Dönüşüm/ Recycling"],
		['code' => "EA 25",'description' => "Elektrik Temini/ Electricity supply"],
		['code' => "EA 26",'description' => "Gaz Temini/ Gas supply"],
		['code' => "EA 27",'description' => "Su temini/ Water supply"],
		['code' => "EA 28",'description' => "Bina, tesis inşaatı/ Construction"],
		['code' => "EA 29",'description' => "Toptan ve per.tic;Mot.araç.mot.kişisel eşya Satışı/ Wholesale & retail trade; G Repair of motor vehicles, motorcycles and Personal and household goods"],
		['code' => "EA 30",'description' => "Hotel ve restoranlar/ Hotels and Restaurant"],
		['code' => "EA 31",'description' => "Ulaştırma, depolama ve iletişim/ Transport, storage and communication"],
		['code' => "EA 32",'description' => "Finansal aracılık; gayri menkul mal; kiralama/ Financial intermediation; Real estate; renting"],
		['code' => "EA 33",'description' => "Bilgi teknolojisi ürünleri/ Information technology"],
		['code' => "EA 34",'description' => "Mühendislik hizmetleri/ Engineering services"],
		['code' => "EA 35",'description' => "Diğer hizmetler/ Other services"],
		['code' => "EA 36",'description' => "Kamu yönetimi/ Public Administration"],
		['code' => "EA 37",'description' => "Eğitim/ Education"],
		['code' => "EA 38",'description' => "Sağlık/ Health and social work"],
		['code' => "EA 39",'description' => "Diğer sosyal hizmetler/ Other social services"],
		];
		
        DB::table('ea_codes')->insert($codes);
     }
}


