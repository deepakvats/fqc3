<?php

use Illuminate\Database\Seeder;

class ComplexitiesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('complexities')->insert([
            'name' => "High",
            ]);
        DB::table('complexities')->insert([
            'name' => "Medium",
            ]);
        DB::table('complexities')->insert([
            'name' => "Low",
            ]);
        DB::table('complexities')->insert([
            'name' => "Limited",
            ]);
    }
}
