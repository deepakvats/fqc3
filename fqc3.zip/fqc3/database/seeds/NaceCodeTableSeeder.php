<?php

use Illuminate\Database\Seeder;


class NaceCodeTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
		          $eacode1 = DB::table('ea_codes')->where('code', 'EA 01')->first()->id;
                  $eacode2 = DB::table('ea_codes')->where('code', 'EA 02')->first()->id;
                  $eacode3 = DB::table('ea_codes')->where('code', 'EA 03')->first()->id;
                  $eacode4 = DB::table('ea_codes')->where('code', 'EA 04')->first()->id;
                  $eacode5 = DB::table('ea_codes')->where('code', 'EA 05')->first()->id;
                  $eacode6 = DB::table('ea_codes')->where('code', 'EA 06')->first()->id;
                  $eacode7 = DB::table('ea_codes')->where('code', 'EA 07')->first()->id;
                  $eacode8 = DB::table('ea_codes')->where('code', 'EA 08')->first()->id;
                  $eacode9 = DB::table('ea_codes')->where('code', 'EA 09')->first()->id;
                  $eacode10 = DB::table('ea_codes')->where('code', 'EA 10')->first()->id;
                  $eacode12 = DB::table('ea_codes')->where('code', 'EA 12')->first()->id;
                  $eacode13 = DB::table('ea_codes')->where('code', 'EA 13')->first()->id;
                  $eacode14 = DB::table('ea_codes')->where('code', 'EA 14')->first()->id;
                  $eacode15 = DB::table('ea_codes')->where('code', 'EA 15')->first()->id;
                  $eacode16 = DB::table('ea_codes')->where('code', 'EA 16')->first()->id;
                  $eacode17 = DB::table('ea_codes')->where('code', 'EA 17')->first()->id;
                  $eacode18 = DB::table('ea_codes')->where('code', 'EA 18')->first()->id;
                  $eacode19 = DB::table('ea_codes')->where('code', 'EA 19')->first()->id;
                  $eacode20 = DB::table('ea_codes')->where('code', 'EA 20')->first()->id;
                  $eacode22 = DB::table('ea_codes')->where('code', 'EA 22')->first()->id;
                  $eacode23 = DB::table('ea_codes')->where('code', 'EA 23')->first()->id;
                  $eacode24 = DB::table('ea_codes')->where('code', 'EA 24')->first()->id;
                  $eacode25 = DB::table('ea_codes')->where('code', 'EA 25')->first()->id;
                  $eacode26 = DB::table('ea_codes')->where('code', 'EA 26')->first()->id;
                  $eacode27 = DB::table('ea_codes')->where('code', 'EA 27')->first()->id;
                  $eacode28 = DB::table('ea_codes')->where('code', 'EA 28')->first()->id;
                  $eacode29 = DB::table('ea_codes')->where('code', 'EA 29')->first()->id;
                  $eacode30 = DB::table('ea_codes')->where('code', 'EA 30')->first()->id;
                  $eacode31 = DB::table('ea_codes')->where('code', 'EA 31')->first()->id;
                  $eacode32 = DB::table('ea_codes')->where('code', 'EA 32')->first()->id;
                  $eacode33 = DB::table('ea_codes')->where('code', 'EA 33')->first()->id;
                  $eacode34 = DB::table('ea_codes')->where('code', 'EA 34')->first()->id;
                  $eacode35 = DB::table('ea_codes')->where('code', 'EA 35')->first()->id;
                  $eacode36 = DB::table('ea_codes')->where('code', 'EA 36')->first()->id;
                  $eacode37 = DB::table('ea_codes')->where('code', 'EA 37')->first()->id;
                  $eacode38 = DB::table('ea_codes')->where('code', 'EA 38')->first()->id;
                  $eacode39 = DB::table('ea_codes')->where('code', 'EA 39')->first()->id;
                
                  
		        $ncodes=[
		            ['code' => "1.0",'description' => "" , 'ea_code_id' => $eacode1],	
		            ['code' => "1.1",'description' => "" , 'ea_code_id' => $eacode1],
		            ['code' => "1.2",'description' => "" , 'ea_code_id' => $eacode1],
		            ['code' => "1.3",'description' => "" , 'ea_code_id' => $eacode1],
                    ['code' => "1.5",'description' => "" , 'ea_code_id' => $eacode1],	
		            ['code' => "1.6",'description' => "" , 'ea_code_id' => $eacode1],
		            ['code' => "1.7",'description' => "" , 'ea_code_id' => $eacode1],
		            ['code' => "2.0",'description' => "" , 'ea_code_id' => $eacode1],
		            ['code' => "2.1",'description' => "" , 'ea_code_id' => $eacode1],
                    ['code' => "2.2",'description' => "" , 'ea_code_id' => $eacode1],
                    ['code' => "2.3",'description' => "" , 'ea_code_id' => $eacode1],
                    ['code' => "2.4",'description' => "" , 'ea_code_id' => $eacode1],
                    ['code' => "3.0",'description' => "" , 'ea_code_id' => $eacode1],
                    ['code' => "3.1",'description' => "" , 'ea_code_id' => $eacode1],
                    ['code' => "3.2",'description' => "" , 'ea_code_id' => $eacode1],
                    
                    
                    ['code' => "5.0",'description' => "" , 'ea_code_id' => $eacode2],
                    ['code' => "5.1",'description' => "" , 'ea_code_id' => $eacode2],
                    ['code' => "5.2",'description' => "" , 'ea_code_id' => $eacode2],
                    ['code' => "6.0",'description' => "" , 'ea_code_id' => $eacode2],
                    ['code' => "6.1",'description' => "" , 'ea_code_id' => $eacode2],
                    ['code' => "7.0",'description' => "" , 'ea_code_id' => $eacode2],
                    ['code' => "7.1",'description' => "" , 'ea_code_id' => $eacode2],
                    ['code' => "7.2",'description' => "" , 'ea_code_id' => $eacode2],
                    ['code' => "8.0",'description' => "" , 'ea_code_id' => $eacode2],
                    ['code' => "8.1",'description' => "" , 'ea_code_id' => $eacode2],
                    ['code' => "8.9",'description' => "" , 'ea_code_id' => $eacode2],
                    ['code' => "9.0",'description' => "" , 'ea_code_id' => $eacode2],
                    ['code' => "9.1",'description' => "" , 'ea_code_id' => $eacode2],
                    ['code' => "9.9",'description' => "" , 'ea_code_id' => $eacode2],
                    
                    
                    ['code' => "10.0",'description' => "" , 'ea_code_id' => $eacode3],
                    ['code' => "10.1",'description' => "" , 'ea_code_id' => $eacode3],
                    ['code' => "10.2",'description' => "" , 'ea_code_id' => $eacode3],
                    ['code' => "10.3",'description' => "" , 'ea_code_id' => $eacode3],
                    ['code' => "10.4",'description' => "" , 'ea_code_id' => $eacode3],
                    ['code' => "10.5",'description' => "" , 'ea_code_id' => $eacode3],
                    ['code' => "10.6",'description' => "" , 'ea_code_id' => $eacode3],
                    ['code' => "10.7",'description' => "" , 'ea_code_id' => $eacode3],
                    ['code' => "10.8",'description' => "" , 'ea_code_id' => $eacode3],
                    ['code' => "10.9",'description' => "" , 'ea_code_id' => $eacode3],
                    ['code' => "11.0",'description' => "" , 'ea_code_id' => $eacode3],
                    ['code' => "11.7",'description' => "" , 'ea_code_id' => $eacode3],
                    ['code' => "12.0",'description' => "" , 'ea_code_id' => $eacode3],
                    

                    
                    ['code' => "13.0",'description' => "" , 'ea_code_id' => $eacode4],
                    ['code' => "13.1",'description' => "" , 'ea_code_id' => $eacode4],
                    ['code' => "13.2",'description' => "" , 'ea_code_id' => $eacode4],
                    ['code' => "13.3",'description' => "" , 'ea_code_id' => $eacode4],
                    ['code' => "13.9",'description' => "" , 'ea_code_id' => $eacode4],
                    ['code' => "14.0",'description' => "" , 'ea_code_id' => $eacode4],
                    ['code' => "14.1",'description' => "" , 'ea_code_id' => $eacode4],
                    ['code' => "14.2",'description' => "" , 'ea_code_id' => $eacode4],
                    ['code' => "14.3",'description' => "" , 'ea_code_id' => $eacode4],
                    
                    
                    
                                        
                    ['code' => "15.0",'description' => "" , 'ea_code_id' => $eacode5],
                    ['code' => "15.1",'description' => "" , 'ea_code_id' => $eacode5],
                    ['code' => "15.2",'description' => "" , 'ea_code_id' => $eacode5],
                    
                    
                    ['code' => "16.0",'description' => "" , 'ea_code_id' => $eacode6],
                    ['code' => "16.1",'description' => "" , 'ea_code_id' => $eacode6],
                    ['code' => "16.2",'description' => "" , 'ea_code_id' => $eacode6],
                    
                    
                    
                    ['code' => "17.0",'description' => "" , 'ea_code_id' => $eacode7],
                    ['code' => "17.1",'description' => "" , 'ea_code_id' => $eacode7],
                    ['code' => "17.2",'description' => "" , 'ea_code_id' => $eacode7],
                   

                    ['code' => "58.0",'description' => "" , 'ea_code_id' => $eacode8],
                    ['code' => "58.1",'description' => "" , 'ea_code_id' => $eacode8],
                    ['code' => "59.0",'description' => "" , 'ea_code_id' => $eacode8],
                    ['code' => "59.2",'description' => "" , 'ea_code_id' => $eacode8],
                    
                    ['code' => "18.0",'description' => "" , 'ea_code_id' => $eacode9],
                    ['code' => "18.1",'description' => "" , 'ea_code_id' => $eacode9],
                    ['code' => "18.2",'description' => "" , 'ea_code_id' => $eacode9],

                    
                    
                    ['code' => "19.0",'description' => "" , 'ea_code_id' => $eacode10],
                    ['code' => "19.1",'description' => "" , 'ea_code_id' => $eacode10],
                    ['code' => "19.2",'description' => "" , 'ea_code_id' => $eacode10],
                    
                    
                                        
                    ['code' => "20.0",'description' => "" , 'ea_code_id' => $eacode12],
                    ['code' => "20.1",'description' => "" , 'ea_code_id' => $eacode12],
                    ['code' => "20.2",'description' => "" , 'ea_code_id' => $eacode12],
                    ['code' => "20.3",'description' => "" , 'ea_code_id' => $eacode12],
                    ['code' => "20.4",'description' => "" , 'ea_code_id' => $eacode12],
                    ['code' => "20.5",'description' => "" , 'ea_code_id' => $eacode12],
                    ['code' => "20.6",'description' => "" , 'ea_code_id' => $eacode12],

                    ['code' => "21.0",'description' => "" , 'ea_code_id' => $eacode13],
                    ['code' => "21.1",'description' => "" , 'ea_code_id' => $eacode13],
                    ['code' => "21.2",'description' => "" , 'ea_code_id' => $eacode13],
                   
                    ['code' => "22.0",'description' => "" , 'ea_code_id' => $eacode14],
                    ['code' => "22.1",'description' => "" , 'ea_code_id' => $eacode14],
                    ['code' => "22.2",'description' => "" , 'ea_code_id' => $eacode14],
                    
                     ['code' => "23.0",'description' => "" , 'ea_code_id' => $eacode15],
                    ['code' => "23.1",'description' => "" , 'ea_code_id' => $eacode15],
                    ['code' => "23.2",'description' => "" , 'ea_code_id' => $eacode15],
                    ['code' => "23.3",'description' => "" , 'ea_code_id' => $eacode15],
                    ['code' => "23.4",'description' => "" , 'ea_code_id' => $eacode15],
                    ['code' => "23.7",'description' => "" , 'ea_code_id' => $eacode15],
                    ['code' => "23.9",'description' => "" , 'ea_code_id' => $eacode15],
                    
                    ['code' => "23.0",'description' => "" , 'ea_code_id' => $eacode16],
                    ['code' => "23.5",'description' => "" , 'ea_code_id' => $eacode16],
                    ['code' => "23.6",'description' => "" , 'ea_code_id' => $eacode16],
                    
                    ['code' => "24.0",'description' => "" , 'ea_code_id' => $eacode17],
                    ['code' => "24.1",'description' => "" , 'ea_code_id' => $eacode17],
                    ['code' => "24.2",'description' => "" , 'ea_code_id' => $eacode17],
                    ['code' => "24.3",'description' => "" , 'ea_code_id' => $eacode17],
                    ['code' => "24.4",'description' => "" , 'ea_code_id' => $eacode17],
                    ['code' => "24.5",'description' => "" , 'ea_code_id' => $eacode17],
                    ['code' => "25.0",'description' => "" , 'ea_code_id' => $eacode17],
                    ['code' => "25.1",'description' => "" , 'ea_code_id' => $eacode17],
                    ['code' => "25.2",'description' => "" , 'ea_code_id' => $eacode17],
                    ['code' => "25.3",'description' => "" , 'ea_code_id' => $eacode17],
                    ['code' => "25.5",'description' => "" , 'ea_code_id' => $eacode17],
                    ['code' => "25.6",'description' => "" , 'ea_code_id' => $eacode17],
                    ['code' => "25.7",'description' => "" , 'ea_code_id' => $eacode17],
                    ['code' => "25.9",'description' => "" , 'ea_code_id' => $eacode17],
                    ['code' => "33.0",'description' => "" , 'ea_code_id' => $eacode17],
                    ['code' => "33.1",'description' => "" , 'ea_code_id' => $eacode17],
                    
                    
                    ['code' => "25.0",'description' => "" , 'ea_code_id' => $eacode18],
                    ['code' => "25.4",'description' => "" , 'ea_code_id' => $eacode18],
                    ['code' => "28.0",'description' => "" , 'ea_code_id' => $eacode18],
                    ['code' => "28.1",'description' => "" , 'ea_code_id' => $eacode18],
                    ['code' => "28.2",'description' => "" , 'ea_code_id' => $eacode18],
                    ['code' => "28.3",'description' => "" , 'ea_code_id' => $eacode18],
                    ['code' => "28.4",'description' => "" , 'ea_code_id' => $eacode18],
                    ['code' => "28.9",'description' => "" , 'ea_code_id' => $eacode18],
                    ['code' => "30.0",'description' => "" , 'ea_code_id' => $eacode18],
                    ['code' => "30.4",'description' => "" , 'ea_code_id' => $eacode18],
                    ['code' => "33.0",'description' => "" , 'ea_code_id' => $eacode18],
                    ['code' => "33.1",'description' => "" , 'ea_code_id' => $eacode18],
                    ['code' => "33.2",'description' => "" , 'ea_code_id' => $eacode18],
                    
                                      
                    ['code' => "26.0",'description' => "" , 'ea_code_id' => $eacode19],
                    ['code' => "26.1",'description' => "" , 'ea_code_id' => $eacode19],
                    ['code' => "26.2",'description' => "" , 'ea_code_id' => $eacode19],
                    ['code' => "26.3",'description' => "" , 'ea_code_id' => $eacode19],
                    ['code' => "26.4",'description' => "" , 'ea_code_id' => $eacode19],
                    ['code' => "26.5",'description' => "" , 'ea_code_id' => $eacode19],
                    ['code' => "26.6",'description' => "" , 'ea_code_id' => $eacode19],
                    ['code' => "26.7",'description' => "" , 'ea_code_id' => $eacode19],
                    ['code' => "26.8",'description' => "" , 'ea_code_id' => $eacode19],
                    ['code' => "27.0",'description' => "" , 'ea_code_id' => $eacode19],
                    ['code' => "27.1",'description' => "" , 'ea_code_id' => $eacode19],
                    ['code' => "27.2",'description' => "" , 'ea_code_id' => $eacode19],
                    ['code' => "27.3",'description' => "" , 'ea_code_id' => $eacode19],
                    ['code' => "27.4",'description' => "" , 'ea_code_id' => $eacode19],
                    ['code' => "27.5",'description' => "" , 'ea_code_id' => $eacode19],
                    ['code' => "27.9",'description' => "" , 'ea_code_id' => $eacode19],
                    ['code' => "33.0",'description' => "" , 'ea_code_id' => $eacode19],
                    ['code' => "33.1",'description' => "" , 'ea_code_id' => $eacode19],
                    ['code' => "95.1",'description' => "" , 'ea_code_id' => $eacode19],
                    
                    ['code' => "30.0",'description' => "" , 'ea_code_id' => $eacode20],
                    ['code' => "30.1",'description' => "" , 'ea_code_id' => $eacode20],
                    ['code' => "33.0",'description' => "" , 'ea_code_id' => $eacode20],
                    ['code' => "33.1",'description' => "" , 'ea_code_id' => $eacode20],
                    
                    
                    ['code' => "29.0",'description' => "" , 'ea_code_id' => $eacode22],
                    ['code' => "29.1",'description' => "" , 'ea_code_id' => $eacode22],
                    ['code' => "29.2",'description' => "" , 'ea_code_id' => $eacode22],
                    ['code' => "29.3",'description' => "" , 'ea_code_id' => $eacode22],
                    ['code' => "30.0",'description' => "" , 'ea_code_id' => $eacode22],
                    ['code' => "30.2",'description' => "" , 'ea_code_id' => $eacode22],
                    ['code' => "30.9",'description' => "" , 'ea_code_id' => $eacode22],
                    ['code' => "33.0",'description' => "" , 'ea_code_id' => $eacode22],
                    ['code' => "33.1",'description' => "" , 'ea_code_id' => $eacode22],
                    
                    
                    ['code' => "31.0",'description' => "" , 'ea_code_id' => $eacode23],
                    ['code' => "32.0",'description' => "" , 'ea_code_id' => $eacode23],
                    ['code' => "32.1",'description' => "" , 'ea_code_id' => $eacode23],
                    ['code' => "32.2",'description' => "" , 'ea_code_id' => $eacode23],
                    ['code' => "32.3",'description' => "" , 'ea_code_id' => $eacode23],
                    ['code' => "32.4",'description' => "" , 'ea_code_id' => $eacode23],
                    ['code' => "32.5",'description' => "" , 'ea_code_id' => $eacode23],
                    ['code' => "32.9",'description' => "" , 'ea_code_id' => $eacode23],
                    ['code' => "33.0",'description' => "" , 'ea_code_id' => $eacode23],
                    ['code' => "33.1",'description' => "" , 'ea_code_id' => $eacode23],
                    
                    ['code' => "38.0",'description' => "" , 'ea_code_id' => $eacode24],
                    ['code' => "38.3",'description' => "" , 'ea_code_id' => $eacode24],
                    
                    ['code' => "35.0",'description' => "" , 'ea_code_id' => $eacode25],
                    ['code' => "35.1",'description' => "" , 'ea_code_id' => $eacode25],
                    
                    ['code' => "35.0",'description' => "" , 'ea_code_id' => $eacode26],
                    ['code' => "35.2",'description' => "" , 'ea_code_id' => $eacode26],
                    
                     ['code' => "35.0",'description' => "" , 'ea_code_id' => $eacode27],
                    ['code' => "35.3",'description' => "" , 'ea_code_id' => $eacode27],
                    ['code' => "36.0",'description' => "" , 'ea_code_id' => $eacode27],
                    
                    
                    
                    ['code' => "41.0",'description' => "" , 'ea_code_id' => $eacode28],
                    ['code' => "41.1",'description' => "" , 'ea_code_id' => $eacode28],
                    ['code' => "41.2",'description' => "" , 'ea_code_id' => $eacode28],
                    ['code' => "42.0",'description' => "" , 'ea_code_id' => $eacode28],
                    ['code' => "42.1",'description' => "" , 'ea_code_id' => $eacode28],
                    ['code' => "42.2",'description' => "" , 'ea_code_id' => $eacode28],
                    ['code' => "42.3",'description' => "" , 'ea_code_id' => $eacode28],
                    ['code' => "42.9",'description' => "" , 'ea_code_id' => $eacode28],
                    ['code' => "43.0",'description' => "" , 'ea_code_id' => $eacode28],
                    ['code' => "43.1",'description' => "" , 'ea_code_id' => $eacode28],
                    ['code' => "43.2",'description' => "" , 'ea_code_id' => $eacode28],
                    ['code' => "43.3",'description' => "" , 'ea_code_id' => $eacode28],
                    ['code' => "43.9",'description' => "" , 'ea_code_id' => $eacode28],
                    
                    
                    
                    ['code' => "45.0",'description' => "" , 'ea_code_id' => $eacode29],
                    ['code' => "45.1",'description' => "" , 'ea_code_id' => $eacode29],
                    ['code' => "45.2",'description' => "" , 'ea_code_id' => $eacode29],
                    ['code' => "45.3",'description' => "" , 'ea_code_id' => $eacode29],
                    ['code' => "45.4",'description' => "" , 'ea_code_id' => $eacode29],
                    ['code' => "46.0",'description' => "" , 'ea_code_id' => $eacode29],
                    ['code' => "46.1",'description' => "" , 'ea_code_id' => $eacode29],
                    ['code' => "46.2",'description' => "" , 'ea_code_id' => $eacode29],
                    ['code' => "46.3",'description' => "" , 'ea_code_id' => $eacode29],
                    ['code' => "46.4",'description' => "" , 'ea_code_id' => $eacode29],
                    ['code' => "46.5",'description' => "" , 'ea_code_id' => $eacode29],
                    ['code' => "46.6",'description' => "" , 'ea_code_id' => $eacode29],
                    ['code' => "46.7",'description' => "" , 'ea_code_id' => $eacode29],
                    ['code' => "46.9",'description' => "" , 'ea_code_id' => $eacode29],
                    ['code' => "47.0",'description' => "" , 'ea_code_id' => $eacode29],
                    ['code' => "47.1",'description' => "" , 'ea_code_id' => $eacode29],
                    ['code' => "47.2",'description' => "" , 'ea_code_id' => $eacode29],
                    ['code' => "47.3",'description' => "" , 'ea_code_id' => $eacode29],
                    ['code' => "47.4",'description' => "" , 'ea_code_id' => $eacode29],
                    ['code' => "47.5",'description' => "" , 'ea_code_id' => $eacode29],
                    ['code' => "47.6",'description' => "" , 'ea_code_id' => $eacode29],
                    ['code' => "47.7",'description' => "" , 'ea_code_id' => $eacode29],
                    ['code' => "47.8",'description' => "" , 'ea_code_id' => $eacode29],
                    ['code' => "47.9",'description' => "" , 'ea_code_id' => $eacode29],
                    ['code' => "95.2",'description' => "" , 'ea_code_id' => $eacode29],
                    
                    
                    ['code' => "55.0",'description' => "" , 'ea_code_id' => $eacode30],
                    ['code' => "55.1",'description' => "" , 'ea_code_id' => $eacode30],
                    ['code' => "55.2",'description' => "" , 'ea_code_id' => $eacode30],
                    ['code' => "55.3",'description' => "" , 'ea_code_id' => $eacode30],
                    ['code' => "55.9",'description' => "" , 'ea_code_id' => $eacode30],
                    ['code' => "56.0",'description' => "" , 'ea_code_id' => $eacode30],
                    ['code' => "56.1",'description' => "" , 'ea_code_id' => $eacode30],
                    ['code' => "56.2",'description' => "" , 'ea_code_id' => $eacode30],
                    ['code' => "56.3",'description' => "" , 'ea_code_id' => $eacode30],
                    
                    
                                        
                    ['code' => "49.0",'description' => "" , 'ea_code_id' => $eacode31],
                    ['code' => "49.1",'description' => "" , 'ea_code_id' => $eacode31],
                    ['code' => "49.2",'description' => "" , 'ea_code_id' => $eacode31],
                    ['code' => "49.3",'description' => "" , 'ea_code_id' => $eacode31],
                    ['code' => "49.4",'description' => "" , 'ea_code_id' => $eacode31],
                    ['code' => "49.5",'description' => "" , 'ea_code_id' => $eacode31],
                    ['code' => "50.0",'description' => "" , 'ea_code_id' => $eacode31],
                    ['code' => "50.1",'description' => "" , 'ea_code_id' => $eacode31],
                    ['code' => "50.2",'description' => "" , 'ea_code_id' => $eacode31],
                    ['code' => "50.3",'description' => "" , 'ea_code_id' => $eacode31],
                    ['code' => "50.4",'description' => "" , 'ea_code_id' => $eacode31],
                    ['code' => "51.0",'description' => "" , 'ea_code_id' => $eacode31],
                    ['code' => "51.2",'description' => "" , 'ea_code_id' => $eacode31],
                    ['code' => "52.0",'description' => "" , 'ea_code_id' => $eacode31],
                    ['code' => "52.1",'description' => "" , 'ea_code_id' => $eacode31],
                    ['code' => "52.2",'description' => "" , 'ea_code_id' => $eacode31],
                    ['code' => "53.0",'description' => "" , 'ea_code_id' => $eacode31],
                    ['code' => "53.1",'description' => "" , 'ea_code_id' => $eacode31],
                    ['code' => "53.2",'description' => "" , 'ea_code_id' => $eacode31],
                    ['code' => "61.0",'description' => "" , 'ea_code_id' => $eacode31],
                    ['code' => "61.1",'description' => "" , 'ea_code_id' => $eacode31],
                    ['code' => "61.2",'description' => "" , 'ea_code_id' => $eacode31],
                    ['code' => "61.3",'description' => "" , 'ea_code_id' => $eacode31],
                    ['code' => "61.9",'description' => "" , 'ea_code_id' => $eacode31],

                    
                    ['code' => "64.0",'description' => "" , 'ea_code_id' => $eacode32],
                    ['code' => "64.1",'description' => "" , 'ea_code_id' => $eacode32],
                    ['code' => "64.2",'description' => "" , 'ea_code_id' => $eacode32],
                    ['code' => "64.3",'description' => "" , 'ea_code_id' => $eacode32],
                    ['code' => "64.9",'description' => "" , 'ea_code_id' => $eacode32],
                    ['code' => "65.0",'description' => "" , 'ea_code_id' => $eacode32],
                    ['code' => "65.1",'description' => "" , 'ea_code_id' => $eacode32],
                    ['code' => "65.2",'description' => "" , 'ea_code_id' => $eacode32],
                    ['code' => "65.3",'description' => "" , 'ea_code_id' => $eacode32],
                    ['code' => "66.0",'description' => "" , 'ea_code_id' => $eacode32],
                    ['code' => "66.1",'description' => "" , 'ea_code_id' => $eacode32],
                    ['code' => "66.2",'description' => "" , 'ea_code_id' => $eacode32],
                    ['code' => "66.3",'description' => "" , 'ea_code_id' => $eacode32],
                    ['code' => "68.0",'description' => "" , 'ea_code_id' => $eacode32],
                    ['code' => "68.1",'description' => "" , 'ea_code_id' => $eacode32],
                    ['code' => "68.2",'description' => "" , 'ea_code_id' => $eacode32],
                    ['code' => "68.3",'description' => "" , 'ea_code_id' => $eacode32],
                    ['code' => "77.0",'description' => "" , 'ea_code_id' => $eacode32],
                    ['code' => "77.1",'description' => "" , 'ea_code_id' => $eacode32],
                    ['code' => "77.2",'description' => "" , 'ea_code_id' => $eacode32],
                    ['code' => "77.3",'description' => "" , 'ea_code_id' => $eacode32],
                    ['code' => "77.4",'description' => "" , 'ea_code_id' => $eacode32],
                    
                    
                    ['code' => "58.0",'description' => "" , 'ea_code_id' => $eacode33],
                    ['code' => "58.2",'description' => "" , 'ea_code_id' => $eacode33],
                    ['code' => "62.0",'description' => "" , 'ea_code_id' => $eacode33],
                    ['code' => "63.0",'description' => "" , 'ea_code_id' => $eacode33],
                    ['code' => "63.1",'description' => "" , 'ea_code_id' => $eacode33],
                    
                    
                             
                    ['code' => "71.0",'description' => "" , 'ea_code_id' => $eacode34],
                    ['code' => "71.1",'description' => "" , 'ea_code_id' => $eacode34],
                    ['code' => "71.2",'description' => "" , 'ea_code_id' => $eacode34],
                    ['code' => "72.0",'description' => "" , 'ea_code_id' => $eacode34],
                    ['code' => "72.1",'description' => "" , 'ea_code_id' => $eacode34],
                    ['code' => "72.2",'description' => "" , 'ea_code_id' => $eacode34],
                    ['code' => "74.0",'description' => "" , 'ea_code_id' => $eacode34],
                    ['code' => "74.1",'description' => "" , 'ea_code_id' => $eacode34],
                    ['code' => "74.9",'description' => "" , 'ea_code_id' => $eacode34],
                    
                    
                    
                    ['code' => "69.0",'description' => "" , 'ea_code_id' => $eacode35],
                    ['code' => "69.1",'description' => "" , 'ea_code_id' => $eacode35],
                    ['code' => "69.2",'description' => "" , 'ea_code_id' => $eacode35],
                    ['code' => "70.0",'description' => "" , 'ea_code_id' => $eacode35],
                    ['code' => "70.1",'description' => "" , 'ea_code_id' => $eacode35],
                    ['code' => "70.2",'description' => "" , 'ea_code_id' => $eacode35],
                    ['code' => "73.0",'description' => "" , 'ea_code_id' => $eacode35],
                    ['code' => "73.1",'description' => "" , 'ea_code_id' => $eacode35],
                    ['code' => "73.2",'description' => "" , 'ea_code_id' => $eacode35],
                    ['code' => "74.0",'description' => "" , 'ea_code_id' => $eacode35],
                    ['code' => "74.2",'description' => "" , 'ea_code_id' => $eacode35],
                    ['code' => "74.3",'description' => "" , 'ea_code_id' => $eacode35],
                    ['code' => "78.0",'description' => "" , 'ea_code_id' => $eacode35],
                    ['code' => "78.1",'description' => "" , 'ea_code_id' => $eacode35],
                    ['code' => "78.2",'description' => "" , 'ea_code_id' => $eacode35],
                    ['code' => "78.3",'description' => "" , 'ea_code_id' => $eacode35],
                    ['code' => "80.0",'description' => "" , 'ea_code_id' => $eacode35],
                    ['code' => "80.1",'description' => "" , 'ea_code_id' => $eacode35],
                    ['code' => "80.2",'description' => "" , 'ea_code_id' => $eacode35],
                    ['code' => "80.3",'description' => "" , 'ea_code_id' => $eacode35],
                    ['code' => "81.0",'description' => "" , 'ea_code_id' => $eacode35],
                    ['code' => "81.1",'description' => "" , 'ea_code_id' => $eacode35],
                    ['code' => "81.2",'description' => "" , 'ea_code_id' => $eacode35],
                    ['code' => "81.3",'description' => "" , 'ea_code_id' => $eacode35],
                    ['code' => "82.0",'description' => "" , 'ea_code_id' => $eacode35],
                    ['code' => "82.1",'description' => "" , 'ea_code_id' => $eacode35],
                    ['code' => "82.2",'description' => "" , 'ea_code_id' => $eacode35],
                    ['code' => "82.3",'description' => "" , 'ea_code_id' => $eacode35],
                    ['code' => "82.9",'description' => "" , 'ea_code_id' => $eacode35],
                    
                    
                    
                    ['code' => "84.0",'description' => "" , 'ea_code_id' => $eacode36],
                    ['code' => "84.1",'description' => "" , 'ea_code_id' => $eacode36],
                    ['code' => "84.2",'description' => "" , 'ea_code_id' => $eacode36],
                    ['code' => "84.3",'description' => "" , 'ea_code_id' => $eacode36],
                    
                    
                    ['code' => "85.0",'description' => "" , 'ea_code_id' => $eacode37],
                    ['code' => "85.1",'description' => "" , 'ea_code_id' => $eacode37],
                    ['code' => "85.2",'description' => "" , 'ea_code_id' => $eacode37],
                    ['code' => "85.3",'description' => "" , 'ea_code_id' => $eacode37],
                    ['code' => "85.4",'description' => "" , 'ea_code_id' => $eacode37],
                    ['code' => "85.5",'description' => "" , 'ea_code_id' => $eacode37],
                    ['code' => "85.6",'description' => "" , 'ea_code_id' => $eacode37],
                    
                    
                              
                    ['code' => "75.0",'description' => "" , 'ea_code_id' => $eacode38],
                    ['code' => "86.0",'description' => "" , 'ea_code_id' => $eacode38],
                    ['code' => "86.1",'description' => "" , 'ea_code_id' => $eacode38],
                    ['code' => "86.2",'description' => "" , 'ea_code_id' => $eacode38],
                    ['code' => "86.9",'description' => "" , 'ea_code_id' => $eacode38],
                    ['code' => "87.0",'description' => "" , 'ea_code_id' => $eacode38],
                    ['code' => "87.1",'description' => "" , 'ea_code_id' => $eacode38],
                    ['code' => "87.2",'description' => "" , 'ea_code_id' => $eacode38],
                    ['code' => "87.3",'description' => "" , 'ea_code_id' => $eacode38],
                    ['code' => "87.9",'description' => "" , 'ea_code_id' => $eacode38],
                    ['code' => "88.0",'description' => "" , 'ea_code_id' => $eacode38],
                    ['code' => "88.1",'description' => "" , 'ea_code_id' => $eacode38],
                    ['code' => "88.9",'description' => "" , 'ea_code_id' => $eacode38],
                    
                    
                    ['code' => "37.0",'description' => "" , 'ea_code_id' => $eacode39],
                    ['code' => "38.0",'description' => "" , 'ea_code_id' => $eacode39],
                    ['code' => "38.1",'description' => "" , 'ea_code_id' => $eacode39],
                    ['code' => "38.2",'description' => "" , 'ea_code_id' => $eacode39],
                    ['code' => "39.0",'description' => "" , 'ea_code_id' => $eacode39],
                    ['code' => "59.0",'description' => "" , 'ea_code_id' => $eacode39],
                    ['code' => "59.1",'description' => "" , 'ea_code_id' => $eacode39],
                    ['code' => "60.0",'description' => "" , 'ea_code_id' => $eacode39],
                    ['code' => "60.1",'description' => "" , 'ea_code_id' => $eacode39],
                    ['code' => "60.2",'description' => "" , 'ea_code_id' => $eacode39],
                    ['code' => "63.0",'description' => "" , 'ea_code_id' => $eacode39],
                    ['code' => "63.9",'description' => "" , 'ea_code_id' => $eacode39],
                    ['code' => "79.0",'description' => "" , 'ea_code_id' => $eacode39],
                    ['code' => "79.1",'description' => "" , 'ea_code_id' => $eacode39],
                    ['code' => "79.9",'description' => "" , 'ea_code_id' => $eacode39],
                    ['code' => "90.0",'description' => "" , 'ea_code_id' => $eacode39],
                    ['code' => "91.0",'description' => "" , 'ea_code_id' => $eacode39],
                    ['code' => "92.0",'description' => "" , 'ea_code_id' => $eacode39],
                    ['code' => "93.0",'description' => "" , 'ea_code_id' => $eacode39],
                    ['code' => "93.1",'description' => "" , 'ea_code_id' => $eacode39],
                    ['code' => "93.2",'description' => "" , 'ea_code_id' => $eacode39],
                    ['code' => "94.0",'description' => "" , 'ea_code_id' => $eacode39],
                    ['code' => "94.1",'description' => "" , 'ea_code_id' => $eacode39],
                    ['code' => "94.2",'description' => "" , 'ea_code_id' => $eacode39],
                    ['code' => "94.9",'description' => "" , 'ea_code_id' => $eacode39],
                    ['code' => "95.0",'description' => "" , 'ea_code_id' => $eacode39],
                    ['code' => "95.1",'description' => "" , 'ea_code_id' => $eacode39],
                    ['code' => "95.2",'description' => "" , 'ea_code_id' => $eacode39],
                    ['code' => "96.0",'description' => "" , 'ea_code_id' => $eacode39],
                    ['code' => "97.0",'description' => "" , 'ea_code_id' => $eacode39],
                    ['code' => "98.0",'description' => "" , 'ea_code_id' => $eacode39],
                    ['code' => "98.1",'description' => "" , 'ea_code_id' => $eacode39],
                    ['code' => "98.2",'description' => "" , 'ea_code_id' => $eacode39],
                    ['code' => "99.0",'description' => "" , 'ea_code_id' => $eacode39],
               
		];
		
        DB::table('nace_codes')->insert($ncodes);       
         
     }
}


