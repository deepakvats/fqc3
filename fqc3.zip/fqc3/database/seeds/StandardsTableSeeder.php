<?php

use Illuminate\Database\Seeder;


class StandardsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
		$standards=[
		 ['name' => "ISO 9001:2015"],
		 ['name' => "ISO 14001:2015"],
		 ['name' => "ISO 22000:2005"],
		 ['name' => "ISO 27001:2013"],
		 ['name' => "ISO 50001:2013"],
		 ['name' => "ISO 45001:2018"],
		 ['name' => "ISO 10002:2014"],
		 ['name' => "ISO 20000-1:2011"],
		 ['name' => "ISO 22301:2012"],
		 ['name' => "ISO 15838:2009"],
		 ['name' => "OHSAS 18001:2007"],
		 ['name' => "ISO 31000:2018"],
		 ['name' => "ISO 28000:2007"],
		 ['name' => "ISO 29990:2010"],
		 ['name' => "ISO 39001:2012"],
		 ['name' => "ISO/TS 22002-1:2009"],
		 ['name' => "ISO 55001:2014"],
		 ['name' => "ISO 13485:2016"],
		 ['name' => "ISO/IEC 20000-1:2011"],
		 ['name' => "ISO 18295-1:2017"],
		 ['name' => "ISO 22716:2007"],
		 ['name' => "EN 15224:2015"],
		];
		
        DB::table('standards')->insert($standards);
    
	}
}



