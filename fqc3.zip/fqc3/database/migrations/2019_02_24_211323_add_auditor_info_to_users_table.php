<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddAuditorInfoToUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->date('date_of_birth')->nullable();
            $table->string('phone')->nullable();;
            $table->string('mobile')->nullable();;
            $table->string('profession')->nullable();;
            $table->string('fax')->nullable();;
            $table->unsignedInteger('address_id')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn('date_of_birth');
            $table->dropColumn('phone');
            $table->dropColumn('mobile');
            $table->dropColumn('profession');
            $table->dropColumn('fax');
            $table->dropForeign(['address_id']);
            $table->dropColumn('address_id');
        });
    }
}
