<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMandaysTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('mandays', function (Blueprint $table) {
            $table->increments('id');
            $table->timestamps();
            $table->integer('minEmployees');
            $table->integer('maxEmployees');
            $table->float('manday',5,2);
            $table->unsignedInteger('standard_id');
			$table->unsignedInteger('complexity_id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('mandays');
    }
}
