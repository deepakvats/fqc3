<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                    <div class="card-header">Create NACE Code</div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <form method="POST" action="">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <?php echo $__env->make('includes.input', ['description' => 'Nace Code', 'type' => 'name', 'name' => 'code', 'value' => old('code')], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <br/><br/>
						<label>Select EA code:</label>
						<select name="eacode">
						 <?php $__currentLoopData = $eacodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($ea->code); ?>"><?php echo e($ea->code); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
						<br/><br/>
                        <label>Description:</label> <textarea name="description"></textarea>
                        <br/><br/>
						
                        <?php echo $__env->make('includes.input', ['description' => '', 'type' => 'submit', 'name' => 'submit', 'value' => 'Submit'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </form>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>