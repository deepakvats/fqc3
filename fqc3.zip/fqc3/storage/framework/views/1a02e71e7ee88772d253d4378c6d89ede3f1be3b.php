<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                    <div class="card-header">Edit Operator</div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
					
				  <div class="row">
    <form method="post" action="<?php echo e(action('Operator\CreateController@update', $id)); ?>" >
        <?php echo e(csrf_field()); ?>

        
        <div class="form-group">
            <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token" />
            <label for="name">Auditor Name:</label>
            <input type="text" class="form-control" name="name" value=<?php echo e($auditor->name); ?> />
        </div>
        <div class="form-group">
            <label for="email">Auditor Email:</label>
			 <input type="text" class="form-control" name="email" value=<?php echo e($auditor->email); ?> />
        </div>
		  
		 <div class="form-group">
            <label for="email">Date Of Birth:</label>
			 <input type="date" class="form-control" name="email" value=<?php echo e($auditor->date_of_birth); ?> />
        </div>
		<div class="form-group">
            <label for="email">Phone:</label>
			 <input type="text" class="form-control" name="email" value=<?php echo e($auditor->phone); ?> />
        </div>
		<div class="form-group">
            <label for="email">Mobile:</label>
			 <input type="text" class="form-control" name="email" value=<?php echo e($auditor->mobile); ?> />
        </div>
		<div class="form-group">
            <label for="email">Profession:</label>
			 <input type="text" class="form-control" name="email" value=<?php echo e($auditor->profession); ?> />
        </div>
		<div class="form-group">
            <label for="email">Fax:</label>
			 <input type="text" class="form-control" name="email" value=<?php echo e($auditor->fax); ?> />
        </div>
		
        <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>