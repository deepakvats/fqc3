<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <?php if(Auth::user()->hasRole("admin")): ?>
                    <div class="card-header">Dashboard of <?php echo e(Auth::user()->roles); ?></div>
                <?php endif; ?>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    You are logged in!
                    <br/>
                    <br/>
                    
                    <div class="row">
                        <div class="col-sm">
                        <button type="button" class="btn btn-primary">New Application Stage</button>
                        </div>
                        <div class="col-sm">
                        <button type="button" class="btn btn-primary">Send Audit Info Notification to client</button>
                        </div>
                        <div class="col-sm">
                        <button type="button" class="btn btn-primary">View Auditor Report Files</button>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>