<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                    <div class="card-header">Create Auditor</div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <form method="POST" action="">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <?php echo $__env->make('includes.input', ['description' => 'Auditor Name', 'type' => 'text', 'name' => 'name', 'value' => old('name')], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <br/><br/>
                        <?php echo $__env->make('includes.input', ['description' => 'Auditor Email', 'type' => 'email', 'name' => 'email', 'value' => old('email')], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <br/><br/>
                        <?php echo $__env->make('includes.input', ['description' => 'Auditor Password', 'type' => 'password', 'name' => 'password', 'value' => old('password')], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                       <br/><br/>
                        <?php echo $__env->make('includes.input', ['description' => 'Date of Birth', 'type' => 'date', 'name' => 'date_of_birth', 'value' => old('date_of_birth')], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <br/><br/>
                        <?php echo $__env->make('includes.input', ['description' => 'Address', 'type' => 'text', 'name' => 'address', 'value' => old('address')], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <br/><br/>
                        <?php echo $__env->make('includes.input', ['description' => 'Phone', 'type' => 'text', 'name' => 'phone', 'value' => old('phone')], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <br/><br/>
                        <?php echo $__env->make('includes.input', ['description' => 'Mobile', 'type' => 'text', 'name' => 'mobile', 'value' => old('mobile')], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <br/><br/>
                        <?php echo $__env->make('includes.input', ['description' => 'Profession', 'type' => 'text', 'name' => 'profession', 'value' => old('profession')], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <br/><br/>
                        <?php echo $__env->make('includes.input', ['description' => 'Fax', 'type' => 'text', 'name' => 'fax', 'value' => old('fax')], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <br/><br/>
                        <?php echo $__env->make('includes.input', ['description' => '', 'type' => 'submit', 'name' => 'submit', 'value' => 'Submit'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </form>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>