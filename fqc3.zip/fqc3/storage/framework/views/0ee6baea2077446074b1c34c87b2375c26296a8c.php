<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                    <div class="card-header">Edit  Standard</div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
					
				  <div class="row">
    <form method="post" action="<?php echo e(action('Standard\CreateController@update', $id)); ?>" >
        <?php echo e(csrf_field()); ?>

        
        <div class="form-group">
            <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token" />
            <label for="name">Standard Name:</label>
            <input type="text" class="form-control" name="name" value="<?php echo e($standard->name); ?>" />
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>